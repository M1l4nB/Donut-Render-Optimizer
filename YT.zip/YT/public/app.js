'use strict';

const app = document.getElementById('app');
const $ = (sel, root = document) => root.querySelector(sel);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const api = async (url) => {
  const r = await fetch(url);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || r.statusText);
  return data;
};
const loading = () => '<div class="loading"><div class="spinner"></div></div>';
const ICON = {
  like: '<svg viewBox="0 0 24 24"><path d="M18.77 11h-4.23l1.52-4.94C16.38 5.03 15.54 4 14.38 4c-.58 0-1.14.24-1.52.65L7 11H3v10h4h1h9.43c1.06 0 1.98-.67 2.19-1.61l1.34-6C21.23 12.15 20.18 11 18.77 11zM7 20H4v-8h3v8zm12.98-6.83l-1.34 6c-.1.48-.61.83-1.21.83H8v-8.61l5.6-6.06c.19-.21.48-.33.78-.33.26 0 .5.11.63.3.07.1.15.26.09.47l-1.52 4.94-.4 1.29h5.58c.41 0 .8.17 1.03.46.13.15.26.4.19.71z"/></svg>',
  share: '<svg viewBox="0 0 24 24"><path d="M15 5.63 20.66 12 15 18.37V14h-1c-3.96 0-7.14 1-9.75 3.09 1.84-4.07 5.11-6.4 9.89-7.1l.86-.13V5.63M14 3v6C6.22 10.13 3.11 15.33 2 21c2.78-3.97 6.44-6 12-6v6l8-9-8-9z"/></svg>',
};

// ---------- stockage local (historique, abonnements) ----------
const store = {
  get(key, def) { try { return JSON.parse(localStorage.getItem(key)) ?? def; } catch { return def; } },
  set(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} },
};
const subs = () => store.get('subs', []);
const isSub = (id) => subs().some((s) => s.id === id);
function toggleSub(ch) {
  const list = subs();
  const i = list.findIndex((s) => s.id === ch.id);
  if (i >= 0) list.splice(i, 1); else list.unshift({ id: ch.id, name: ch.name, avatar: ch.avatar });
  store.set('subs', list);
  renderGuideSubs();
  return i < 0;
}
function addHistory(v) {
  const list = store.get('history', []).filter((h) => h.id !== v.id);
  list.unshift({ kind: 'video', id: v.id, title: v.title, thumb: `/img?u=${encodeURIComponent(`https://i.ytimg.com/vi/${v.id}/hqdefault.jpg`)}`,
    channel: v.channel, channelId: v.channelId, avatar: v.avatar, views: v.views, published: v.relative || v.published, duration: v.durationText });
  store.set('history', list.slice(0, 300));
}

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  document.body.append(t);
  setTimeout(() => t.remove(), 2500);
}

function subscribeButton(ch) {
  const b = document.createElement('button');
  const paint = () => { const on = isSub(ch.id); b.className = 'subscribe' + (on ? ' on' : ''); b.textContent = on ? 'Abonné' : "S'abonner"; };
  paint();
  b.onclick = () => { const on = toggleSub(ch); paint(); toast(on ? 'Abonnement ajouté' : 'Abonnement supprimé'); };
  return b;
}

// ---------- menu de gauche ----------
function renderGuideSubs() {
  const list = subs();
  $('#guide-subs').innerHTML = list.length
    ? list.map((s) => `<a href="/channel?id=${esc(s.id)}" data-link><img src="${esc(s.avatar)}" alt="" loading="lazy"><span>${esc(s.name)}</span></a>`).join('')
    : '<div class="empty">Abonnez-vous à des chaînes pour les retrouver ici.</div>';
}
$('#menu-btn').onclick = () => {
  if (document.body.classList.contains('watch') || innerWidth <= 792) document.body.classList.toggle('drawer');
  else document.body.classList.toggle('mini');
};
$('#scrim').onclick = () => document.body.classList.remove('drawer');

// ---------- éléments de liste ----------
const durationBadge = (v) => v.live ? '<span class="duration live">EN DIRECT</span>'
  : v.duration ? `<span class="duration">${esc(v.duration)}</span>` : '';
const subLine = (v) => [v.views, v.published].filter(Boolean).map(esc).join(' • ');
const chanLink = (v, inner) => v.channelId ? `<a href="/channel?id=${esc(v.channelId)}" data-link>${inner}</a>` : inner;

function card(v) {
  return `<div class="card">
    <a class="thumb" href="/watch?v=${esc(v.id)}" data-link><img src="${esc(v.thumb)}" alt="" loading="lazy">${durationBadge(v)}</a>
    <div class="details">
      ${v.avatar ? chanLink(v, `<img class="avatar" src="${esc(v.avatar)}" alt="" loading="lazy">`) : ''}
      <div class="meta">
        <a href="/watch?v=${esc(v.id)}" data-link><h3 class="title">${esc(v.title)}</h3></a>
        <div class="sub">${chanLink(v, esc(v.channel))}</div>
        <div class="sub">${subLine(v)}</div>
      </div>
    </div>
  </div>`;
}

function resultRow(v) {
  if (v.kind === 'channel') {
    return `<a class="channel-result" href="/channel?id=${esc(v.id)}" data-link>
      <div class="ch-av"><img src="${esc(v.avatar)}" alt="" loading="lazy"></div>
      <div class="meta"><h3 class="title">${esc(v.title)}</h3>
        <div class="sub">${[v.handle, v.subs].filter(Boolean).map(esc).join(' • ')}</div>
        <div class="sub">${esc(v.description)}</div></div>
    </a>`;
  }
  return `<div class="result">
    <a class="thumb" href="/watch?v=${esc(v.id)}" data-link><img src="${esc(v.thumb)}" alt="" loading="lazy">${durationBadge(v)}</a>
    <div class="meta">
      <a href="/watch?v=${esc(v.id)}" data-link><h3 class="title">${esc(v.title)}</h3></a>
      <div class="sub">${subLine(v)}</div>
      <div class="chan-line">${chanLink(v, `${v.avatar ? `<img class="avatar" src="${esc(v.avatar)}" alt="" loading="lazy">` : ''}`)}${chanLink(v, esc(v.channel))}</div>
    </div>
  </div>`;
}

function compact(v) {
  return `<div class="compact">
    <a class="thumb" href="/watch?v=${esc(v.id)}" data-link><img src="${esc(v.thumb)}" alt="" loading="lazy">${durationBadge(v)}</a>
    <div class="meta">
      <a href="/watch?v=${esc(v.id)}" data-link><h3 class="title">${esc(v.title)}</h3></a>
      <div class="sub">${chanLink(v, esc(v.channel))}</div>
      <div class="sub">${subLine(v)}</div>
    </div>
  </div>`;
}

// Défilement infini : charge la page suivante quand le bas de liste devient visible.
function infinite(container, next, render, moreUrl = (t) => `/api/more/${t}`) {
  if (!next) return;
  const sentinel = document.createElement('div');
  sentinel.className = 'sentinel';
  container.after(sentinel);
  let busy = false;
  const io = new IntersectionObserver(async ([e]) => {
    if (!e.isIntersecting || busy || !next) return;
    busy = true;
    try {
      const data = await api(moreUrl(next));
      container.insertAdjacentHTML('beforeend', data.items.map(render).join(''));
      next = data.next;
    } catch { next = null; }
    busy = false;
    if (!next) { io.disconnect(); sentinel.remove(); }
  }, { rootMargin: '800px' });
  io.observe(sentinel);
  cleanup.push(() => io.disconnect());
}

// ---------- pages ----------
let cleanup = [];

const CATS = [['all', 'Tout'], ['music', 'Musique'], ['gaming', 'Jeux vidéo'], ['minecraft', 'Minecraft'], ['news', 'Actualités'],
  ['sport', 'Sport'], ['cooking', 'Cuisine'], ['science', 'Science'], ['comedy', 'Humour'], ['live', 'En direct']];

async function pageHome(params) {
  const cat = params.get('cat') || 'all';
  app.innerHTML = `<div class="chips">${CATS.map(([k, l]) =>
    `<a class="chip${k === cat ? ' active' : ''}" href="/${k === 'all' ? '' : '?cat=' + k}" data-link>${l}</a>`).join('')}</div>
    <div id="feed">${loading()}</div>`;
  const data = await api('/api/home?cat=' + cat);
  $('#feed').outerHTML = data.items.length ? `<div class="grid">${data.items.map(card).join('')}</div>`
    : '<div class="empty-state">Aucune vidéo trouvée.</div>';
}

async function pageSearch(params) {
  const q = params.get('search_query') || '';
  $('#search-input').value = q;
  document.title = `${q} - Tube`;
  app.innerHTML = `<div class="results" id="results">${loading()}</div>`;
  const data = await api('/api/search?q=' + encodeURIComponent(q));
  const box = $('#results');
  box.innerHTML = data.items.length ? data.items.map(resultRow).join('') : '<div class="empty-state">Aucun résultat.</div>';
  infinite(box, data.next, resultRow);
}

async function pageChannel(params) {
  const id = params.get('id');
  app.innerHTML = loading();
  const ch = await api('/api/channel/' + encodeURIComponent(id));
  document.title = `${ch.title} - Tube`;
  app.innerHTML = `<div class="channel-page">
    ${ch.banner ? `<div class="banner"><img src="${esc(ch.banner)}" alt=""></div>` : ''}
    <div class="ch-head">
      <img src="${esc(ch.avatar)}" alt="">
      <div><h1>${esc(ch.title)}</h1><div class="sub">${esc(ch.subs)}</div><div class="desc">${esc(ch.description)}</div><div id="sub-slot"></div></div>
    </div>
    <div class="tabs"><span>Vidéos</span></div>
    <div class="grid" id="ch-grid">${ch.items.map(card).join('') || '<div class="empty-state">Aucune vidéo.</div>'}</div>
  </div>`;
  $('#sub-slot').append(subscribeButton({ id: ch.id, name: ch.title, avatar: ch.avatar }));
  infinite($('#ch-grid'), ch.next, card);
}

function pageHistory() {
  document.title = 'Historique - Tube';
  const list = store.get('history', []);
  app.innerHTML = `<div class="results">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <h1 class="page-title">Historique</h1>
      ${list.length ? '<button class="pill" id="clear-hist">Effacer l\'historique</button>' : ''}
    </div>
    ${list.length ? list.map(resultRow).join('') : '<div class="empty-state">Les vidéos que vous regardez apparaîtront ici.</div>'}
  </div>`;
  const btn = $('#clear-hist');
  if (btn) btn.onclick = () => { store.set('history', []); pageHistory(); };
}

async function pageSubscriptions() {
  document.title = 'Abonnements - Tube';
  const list = subs();
  if (!list.length) {
    app.innerHTML = '<div class="empty-state">Vous n\'êtes abonné à aucune chaîne.<br>Cliquez sur « S\'abonner » sous une vidéo ou sur une chaîne.</div>';
    return;
  }
  app.innerHTML = `<h1 class="page-title">Abonnements</h1><div id="feed">${loading()}</div>`;
  const pages = await Promise.all(list.slice(0, 30).map((s) => api('/api/channel/' + encodeURIComponent(s.id)).catch(() => null)));
  const lists = pages.filter(Boolean).map((p) => p.items.slice(0, 12).map((v) => ({ ...v, channel: p.title, channelId: p.id, avatar: p.avatar })));
  const out = [];
  for (let i = 0; lists.some((l) => i < l.length); i++) for (const l of lists) if (l[i]) out.push(l[i]);
  $('#feed').outerHTML = `<div class="grid">${out.map(card).join('')}</div>`;
}

// ---------- lecteur ----------
// YouTube sépare image et son au-delà de 360p : une <video> muette + un <audio> synchronisé.
function mountPlayer(box, id, startAt) {
  box.innerHTML = '<div class="msg"><div class="spinner"></div></div>';
  let hls, timer, alive = true;
  cleanup.push(() => { alive = false; clearInterval(timer); hls?.destroy(); box.querySelectorAll('video,audio').forEach((m) => { m.pause(); m.removeAttribute('src'); m.load(); }); });

  api('/api/streams/' + id).then((s) => {
    if (!alive) return;
    const video = document.createElement('video');
    video.controls = true; video.autoplay = true; video.playsInline = true;
    video.volume = store.get('volume', 1);
    box.innerHTML = '';
    box.append(video);

    if (s.live) {
      if (!s.hls) throw new Error('Direct indisponible');
      if (video.canPlayType('application/vnd.apple.mpegurl')) video.src = s.hls;
      else if (window.Hls?.isSupported()) { hls = new Hls(); hls.loadSource(s.hls); hls.attachMedia(video); }
      else throw new Error('Les directs ne sont pas pris en charge par ce navigateur');
      return;
    }

    const pref = store.get('quality', 720);
    const options = s.qualities.filter((q) => video.canPlayType(q.mime.replace('webm', 'webm; codecs="vp9"')) !== '' || q.mime === 'video/mp4');
    if (!s.audio || !options.length) {
      if (!s.muxed) throw new Error('Aucun flux lisible');
      video.src = `/stream/${id}/${s.muxed.itag}`;
      video.currentTime = startAt || 0;
      return;
    }
    const audio = document.createElement('audio');
    audio.src = `/stream/${id}/${s.audio.itag}`;
    audio.preload = 'auto';
    box.append(audio);

    let current = options.find((q) => q.height <= pref) || options[options.length - 1];
    video.src = `/stream/${id}/${current.itag}`;
    video.muted = false;
    if (startAt) video.currentTime = startAt;

    // synchronisation son/image
    const syncAudio = () => { if (Math.abs(audio.currentTime - video.currentTime) > 0.2) audio.currentTime = video.currentTime; };
    video.addEventListener('play', () => { syncAudio(); audio.play().catch(() => {}); });
    video.addEventListener('playing', () => { syncAudio(); audio.play().catch(() => {}); });
    video.addEventListener('pause', () => audio.pause());
    video.addEventListener('waiting', () => audio.pause());
    video.addEventListener('seeking', () => { audio.currentTime = video.currentTime; });
    video.addEventListener('ratechange', () => { audio.playbackRate = video.playbackRate; });
    video.addEventListener('volumechange', () => { audio.volume = video.volume; audio.muted = video.muted; store.set('volume', video.volume); });
    video.addEventListener('ended', () => audio.pause());
    audio.addEventListener('waiting', () => { if (!video.paused) { video.pause(); audio.addEventListener('canplay', () => video.play(), { once: true }); } });
    audio.volume = video.volume;
    timer = setInterval(() => { if (!video.paused && Math.abs(audio.currentTime - video.currentTime) > 0.3) audio.currentTime = video.currentTime; }, 1000);

    // choix de la qualité
    const q = document.createElement('div');
    q.className = 'quality';
    q.innerHTML = `<select aria-label="Qualité">${options.map((o) => `<option value="${esc(o.itag)}"${o === current ? ' selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`;
    box.append(q);
    q.firstChild.onchange = (e) => {
      current = options.find((o) => o.itag === e.target.value);
      store.set('quality', current.height);
      const t = video.currentTime, paused = video.paused;
      video.src = `/stream/${id}/${current.itag}`;
      video.currentTime = t;
      if (!paused) video.play().catch(() => {});
    };
  }).catch((e) => {
    if (alive) box.innerHTML = `<div class="msg">Impossible de lire cette vidéo.<br><small>${esc(e.message)}</small></div>`;
  });
}

// Liens cliquables et horodatages dans la description et les commentaires.
function richText(text) {
  return esc(text)
    .replace(/https?:\/\/[^\s<]+/g, (u) => {
      const yt = u.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
      return yt ? `<a href="/watch?v=${yt[1]}" data-link>${u}</a>` : `<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>`;
    })
    .replace(/(^|\s)((?:\d{1,2}:)?\d{1,2}:\d{2})(?=\s|$)/gm, (m, pre, t) => {
      const sec = t.split(':').reduce((a, b) => a * 60 + Number(b), 0);
      return `${pre}<a href="#" data-seek="${sec}">${t}</a>`;
    });
}

const fmtCount = (n) => n == null ? '' : n >= 1e6 ? (n / 1e6).toFixed(1).replace('.0', '') + ' M' : n >= 1e3 ? Math.round(n / 1e3) + ' k' : String(n);

async function pageWatch(params) {
  const id = params.get('v');
  if (!/^[\w-]{11}$/.test(id || '')) { app.innerHTML = '<div class="empty-state">Vidéo introuvable.</div>'; return; }
  const startAt = Number(params.get('t')) || 0;
  app.innerHTML = `<div class="watch-page">
    <div class="primary"><div class="player" id="player"></div><div id="info">${loading()}</div><div class="comments" id="comments"></div></div>
    <div class="secondary" id="related"></div>
  </div>`;
  mountPlayer($('#player'), id, startAt);

  const v = await api('/api/video/' + id);
  document.title = `${v.title} - Tube`;
  const m = Math.floor(v.duration / 60), s = v.duration % 60;
  v.durationText = v.live ? '' : `${m}:${String(s).padStart(2, '0')}`;
  addHistory(v);

  $('#info').innerHTML = `<h1 class="watch-title">${esc(v.title)}</h1>
    <div class="owner-row">
      <div class="owner">
        <a href="/channel?id=${esc(v.channelId)}" data-link><img class="avatar" src="${esc(v.avatar)}" alt=""></a>
        <div><a class="name" href="/channel?id=${esc(v.channelId)}" data-link>${esc(v.channel)}</a><div class="subs">${esc(v.subs)}</div></div>
        <span id="sub-slot"></span>
      </div>
      <div class="actions">
        ${v.likes != null ? `<button class="pill" disabled>${ICON.like}${fmtCount(v.likes)}</button>` : ''}
        <button class="pill" id="share">${ICON.share}Partager</button>
      </div>
    </div>
    <div class="description" id="desc">
      <div class="stats">${esc(v.views)}  ${esc(v.published)}</div>
      <div class="text">${richText(v.description)}</div>
      <div class="more">...plus</div>
    </div>`;
  $('#sub-slot').append(subscribeButton({ id: v.channelId, name: v.channel, avatar: v.avatar }));
  $('#share').onclick = async () => {
    const url = `${location.origin}/watch?v=${id}`;
    try { await navigator.clipboard.writeText(url); toast('Lien copié'); } catch { prompt('Lien de la vidéo :', url); }
  };
  const desc = $('#desc');
  desc.onclick = (e) => {
    if (e.target.closest('a')) return;
    if (!desc.classList.contains('open')) { desc.classList.add('open'); desc.querySelector('.more').textContent = 'Moins'; }
    else if (e.target.classList.contains('more')) { desc.classList.remove('open'); e.target.textContent = '...plus'; }
  };
  $('#related').innerHTML = v.related.map(compact).join('');

  // commentaires
  const box = $('#comments');
  box.innerHTML = loading();
  api('/api/comments/' + id).then((c) => {
    const render = (x) => `<div class="comment">
      <img class="avatar" src="${esc(x.avatar)}" alt="" loading="lazy">
      <div><div class="who">${esc(x.author)}<span>${esc(x.time)}</span></div>
      <div class="body">${richText(x.text)}</div>
      <div class="foot"><span>${ICON.like}${esc(x.likes)}</span>${x.replies ? `<span>${esc(x.replies)} réponse${x.replies === '1' ? '' : 's'}</span>` : ''}</div></div>
    </div>`;
    box.innerHTML = `<h2>${esc(c.count || 'Commentaires')}</h2><div id="comment-list">${c.items.map(render).join('')}</div>`;
    infinite($('#comment-list'), c.next, render, (t) => `/api/comments-more/${t}`);
  }).catch(() => { box.innerHTML = '<h2>Commentaires</h2><div class="sub">Commentaires indisponibles.</div>'; });
}

// ---------- routage ----------
async function route() {
  cleanup.forEach((f) => f()); cleanup = [];
  const params = new URLSearchParams(location.search);
  const path = location.pathname;
  document.body.classList.toggle('watch', path === '/watch');
  document.body.classList.remove('drawer');
  document.title = 'Tube';
  document.querySelectorAll('[data-nav]').forEach((a) => a.classList.toggle('active',
    a.dataset.nav === (path === '/' ? 'home' : path.slice(1))));
  if (path !== '/results') $('#search-input').value = '';
  scrollTo(0, 0);
  try {
    if (path === '/watch') await pageWatch(params);
    else if (path === '/results') await pageSearch(params);
    else if (path === '/channel') await pageChannel(params);
    else if (path === '/history') pageHistory();
    else if (path === '/subscriptions') await pageSubscriptions();
    else await pageHome(params);
  } catch (e) {
    app.innerHTML = `<div class="empty-state">Une erreur est survenue.<br><small>${esc(e.message)}</small></div>`;
  }
}

function go(url) { history.pushState(null, '', url); route(); }

document.addEventListener('click', (e) => {
  const seek = e.target.closest('[data-seek]');
  if (seek) {
    e.preventDefault();
    const video = $('#player video');
    if (video) { video.currentTime = Number(seek.dataset.seek); video.play().catch(() => {}); scrollTo({ top: 0, behavior: 'smooth' }); }
    return;
  }
  const a = e.target.closest('a[data-link]');
  if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
  e.preventDefault();
  go(a.getAttribute('href'));
});
addEventListener('popstate', route);

$('#search-form').onsubmit = (e) => {
  e.preventDefault();
  const q = $('#search-input').value.trim();
  if (!q) return;
  // un lien YouTube collé ouvre directement la vidéo
  const m = q.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/);
  go(m ? `/watch?v=${m[1]}` : `/results?search_query=${encodeURIComponent(q)}`);
  $('#search-input').blur();
};

// raccourcis clavier façon YouTube
document.addEventListener('keydown', (e) => {
  if (e.target.matches('input, textarea, select')) {
    return;
  }
  if (e.key === '/') { e.preventDefault(); $('#search-input').focus(); return; }
  const v = $('#player video');
  if (!v || e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase();
  if (k === 'k' || (k === ' ' && e.target === document.body)) { e.preventDefault(); v.paused ? v.play() : v.pause(); }
  else if (k === 'j') v.currentTime -= 10;
  else if (k === 'l') v.currentTime += 10;
  else if (k === 'arrowleft') { e.preventDefault(); v.currentTime -= 5; }
  else if (k === 'arrowright') { e.preventDefault(); v.currentTime += 5; }
  else if (k === 'm') v.muted = !v.muted;
  else if (k === 'f') document.fullscreenElement ? document.exitFullscreen() : $('#player').requestFullscreen();
});

renderGuideSubs();
route();
