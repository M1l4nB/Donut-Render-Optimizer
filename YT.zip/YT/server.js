// Interface YouTube auto-hébergée : le serveur récupère métadonnées, miniatures
// et flux vidéo, les clients du réseau ne parlent qu'à lui.
import express from 'express';
import { Innertube, Log } from 'youtubei.js';
import { execFile } from 'node:child_process';
import { Readable } from 'node:stream';
import { randomUUID, createHash, timingSafeEqual } from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PORT = Number(process.env.PORT) || 8080;
const HOST = process.env.HOST || '0.0.0.0';
const PYTHON = process.env.PYTHON || 'python';
const CHUNK = 10 * 1024 * 1024; // YouTube bride les requêtes de plage trop grandes
const __dirname = path.dirname(fileURLToPath(import.meta.url));

Log.setLevel(Log.Level.NONE);
let yt;
async function client() {
  if (!yt) yt = await Innertube.create({ retrieve_player: false, lang: 'fr', location: 'FR' });
  return yt;
}

// ---------- utilitaires ----------
const str = (v) => (v == null ? '' : typeof v === 'string' ? v : v.text ?? v.toString?.() ?? '');
const firstUrl = (arr) => {
  if (!Array.isArray(arr) || !arr.length) return '';
  const u = arr[0].url || '';
  return u.startsWith('//') ? 'https:' + u : u;
};
const img = (u) => (u ? '/img?u=' + encodeURIComponent(u) : '');
const channelIdIn = (obj) => JSON.stringify(obj ?? '').match(/UC[\w-]{22}/)?.[0] || '';

// Normalise les différents types d'éléments vidéo renvoyés par YouTube.
function normalize(item) {
  if (!item) return null;
  if (item.type === 'RichItem') return normalize(item.content);
  if (item.type === 'Video' || item.type === 'CompactVideo' || item.type === 'GridVideo') {
    const id = item.video_id || item.id;
    if (!id) return null;
    return {
      kind: 'video', id,
      title: str(item.title),
      thumb: img(`https://i.ytimg.com/vi/${id}/hqdefault.jpg`),
      duration: str(item.length_text) || (item.is_live ? 'EN DIRECT' : ''),
      live: !!item.is_live,
      channel: item.author?.name || '',
      channelId: item.author?.id || '',
      avatar: img(firstUrl(item.author?.thumbnails)),
      views: str(item.short_view_count) || str(item.view_count),
      published: str(item.published),
    };
  }
  if (item.type === 'LockupView') {
    if (item.content_type !== 'VIDEO') return null;
    const id = item.content_id;
    const badges = (item.content_image?.overlays || []).flatMap((o) => o.badges || []);
    const badge = badges.map((b) => b.text).find(Boolean) || '';
    const rows = (item.metadata?.metadata?.metadata_rows || []).map((r) =>
      (r.metadata_parts || []).map((p) => str(p.text)).filter(Boolean));
    let channel = '', meta = [];
    if (rows.length >= 2) { channel = rows[0].join(' '); meta = rows.slice(1).flat(); }
    else meta = rows.flat();
    return {
      kind: 'video', id,
      title: str(item.metadata?.title),
      thumb: img(`https://i.ytimg.com/vi/${id}/hqdefault.jpg`),
      duration: badge,
      live: badges.some((b) => /LIVE/.test(b.badge_style || b.icon_name || '')),
      channel,
      channelId: channelIdIn(item.metadata?.image),
      avatar: img(firstUrl(item.metadata?.image?.avatar?.image)),
      views: meta[0] || '',
      published: meta.slice(1).join(' • '),
    };
  }
  if (item.type === 'Channel') {
    return {
      kind: 'channel',
      id: item.author?.id || item.id,
      title: item.author?.name || '',
      avatar: img(firstUrl(item.author?.thumbnails)),
      subs: str(item.subscriber_count),
      handle: str(item.video_count),
      description: str(item.description_snippet),
    };
  }
  return null;
}
const normalizeAll = (list) => (list || []).map(normalize).filter(Boolean);

// Les continuations (pages suivantes) restent côté serveur, le client ne reçoit qu'un jeton.
const continuations = new Map();
function keep(obj, hasMore) {
  if (!hasMore) return null;
  const token = randomUUID();
  continuations.set(token, { obj, t: Date.now() });
  for (const [k, v] of continuations) if (Date.now() - v.t > 3600e3) continuations.delete(k);
  return token;
}

const wrap = (fn) => async (req, res) => {
  try { res.json(await fn(req, res)); }
  catch (e) { console.error(req.path, e.message); res.status(500).json({ error: e.message }); }
};

// ---------- API métadonnées ----------
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 'loopback');

// Mot de passe (TUBE_PASSWORD) : authentification HTTP du navigateur, demandée une fois
// puis renvoyée automatiquement, y compris pour les requêtes vidéo.
const PASSWORD = process.env.TUBE_PASSWORD || '';
const digest = (s) => createHash('sha256').update(s).digest();
if (PASSWORD) {
  const expected = digest(PASSWORD);
  app.use((req, res, next) => {
    const [scheme, b64] = (req.headers.authorization || '').split(' ');
    const pass = scheme === 'Basic' ? Buffer.from(b64 || '', 'base64').toString().split(':').slice(1).join(':') : '';
    if (pass && timingSafeEqual(digest(pass), expected)) return next();
    res.set('WWW-Authenticate', 'Basic realm="Tube", charset="UTF-8"').status(401).send('Mot de passe requis');
  });
}
app.use(express.static(path.join(__dirname, 'public')));
app.get('/vendor/hls.js', (_, res) => res.sendFile(path.join(__dirname, 'node_modules/hls.js/dist/hls.min.js')));

const HOME_QUERIES = {
  all: ['clip officiel', 'jeux vidéo', 'humour', 'actualités france', 'documentaire', 'minecraft'],
  music: ['musique', 'clip officiel'], gaming: ['jeux vidéo', 'gameplay'], minecraft: ['minecraft'],
  news: ['actualités'], sport: ['sport résumé'], cooking: ['recette cuisine'], science: ['science vulgarisation'],
  comedy: ['humour sketch'], live: ['en direct'],
};

app.get('/api/home', wrap(async (req) => {
  const yt = await client();
  const queries = HOME_QUERIES[req.query.cat] || HOME_QUERIES.all;
  const pages = await Promise.all(queries.map((q) =>
    yt.search(q, { upload_date: req.query.cat === 'live' ? 'all' : 'week', type: 'video', prioritize: 'popularity',
      ...(req.query.cat === 'live' ? { features: ['live'] } : {}) }).catch(() => null)));
  const lists = pages.filter(Boolean).map((p) => normalizeAll(p.results));
  const seen = new Set(), out = [];
  for (let i = 0; lists.some((l) => i < l.length); i++)
    for (const l of lists) { const v = l[i]; if (v && v.kind === 'video' && !seen.has(v.id)) { seen.add(v.id); out.push(v); } }
  return { items: out };
}));

app.get('/api/search', wrap(async (req) => {
  const yt = await client();
  const q = String(req.query.q || '').slice(0, 200);
  const s = await yt.search(q);
  return { items: normalizeAll(s.results), next: keep(s, s.has_continuation) };
}));

app.get('/api/more/:token', wrap(async (req) => {
  const entry = continuations.get(req.params.token);
  if (!entry) return { items: [], next: null };
  continuations.delete(req.params.token);
  const page = await entry.obj.getContinuation();
  const list = page.results || page.videos || page.contents?.contents || page.contents || [];
  return { items: normalizeAll(list), next: keep(page, page.has_continuation) };
}));

app.get('/api/video/:id', wrap(async (req) => {
  const yt = await client();
  const info = await yt.getInfo(req.params.id);
  const p = info.primary_info, s = info.secondary_info, b = info.basic_info;
  return {
    id: req.params.id,
    title: str(p?.title) || b.title,
    views: str(p?.view_count?.view_count) || String(b.view_count ?? ''),
    published: str(p?.published),
    relative: str(p?.relative_date),
    likes: b.like_count ?? null,
    live: !!b.is_live,
    duration: b.duration,
    description: str(s?.description) || b.short_description || '',
    channel: s?.owner?.author?.name || b.author,
    channelId: s?.owner?.author?.id || b.channel_id,
    avatar: img(firstUrl(s?.owner?.author?.thumbnails)),
    subs: str(s?.owner?.subscriber_count),
    related: normalizeAll(info.watch_next_feed),
  };
}));

const mapComments = (list) => (list || []).filter((t) => t.comment).map((t) => ({
  author: t.comment.author?.name || '',
  avatar: img(firstUrl(t.comment.author?.thumbnails)),
  channelId: t.comment.author?.id || '',
  text: str(t.comment.content),
  time: t.comment.published_time || '',
  likes: t.comment.like_count || '',
  replies: t.comment.reply_count || '',
}));

app.get('/api/comments/:id', wrap(async (req) => {
  const yt = await client();
  const c = await yt.getComments(req.params.id);
  return { count: str(c.header?.count), items: mapComments(c.contents), next: keep(c, c.has_continuation) };
}));

app.get('/api/comments-more/:token', wrap(async (req) => {
  const entry = continuations.get(req.params.token);
  if (!entry) return { items: [], next: null };
  continuations.delete(req.params.token);
  const c = await entry.obj.getContinuation();
  return { items: mapComments(c.contents), next: keep(c, c.has_continuation) };
}));

app.get('/api/channel/:id', wrap(async (req) => {
  const yt = await client();
  const ch = await yt.getChannel(req.params.id);
  const md = ch.metadata || {};
  const header = JSON.stringify(ch.header || {});
  const banner = header.match(/"url":"(https:[^"]+?(?:=w\d+[^"]*))"/)?.[1] || '';
  const subs = header.match(/"text":"([^"]*abonn[^"]*)"/i)?.[1] || header.match(/"text":"([^"]*subscri[^"]*)"/i)?.[1] || '';
  let videos = { videos: [], has_continuation: false };
  try { videos = await ch.getVideos(); } catch {}
  return {
    id: req.params.id,
    title: md.title || '',
    avatar: img(firstUrl(md.avatar)),
    banner: img(banner),
    subs,
    description: md.description || '',
    items: normalizeAll(videos.videos),
    next: keep(videos, videos.has_continuation),
  };
}));

// ---------- flux vidéo (via yt-dlp) ----------
const streamCache = new Map(); // id -> { expires, formats: Map(itag -> format), info }
const pending = new Map();

function ytdlp(id) {
  return new Promise((resolve, reject) => {
    execFile(PYTHON, ['-m', 'yt_dlp', '-j', '--no-warnings', '--no-playlist', '--js-runtimes', 'node',
      '--', `https://www.youtube.com/watch?v=${id}`],
    { maxBuffer: 64 * 1024 * 1024, timeout: 90e3, windowsHide: true }, (err, stdout, stderr) => {
      if (err) return reject(new Error((stderr || err.message).trim().split('\n').pop()));
      try { resolve(JSON.parse(stdout)); } catch (e) { reject(e); }
    });
  });
}

async function streams(id, force = false) {
  if (!/^[\w-]{11}$/.test(id)) throw new Error('identifiant invalide');
  const c = streamCache.get(id);
  if (c && !force && c.expires > Date.now()) return c;
  if (pending.has(id)) return pending.get(id);
  const p = ytdlp(id).then((info) => {
    const formats = new Map(info.formats.map((f) => [String(f.format_id), f]));
    const exp = Number(new URL(info.formats.find((f) => f.url)?.url || 'http://x/?expire=0').searchParams.get('expire'));
    const entry = { info, formats, expires: Math.min(exp ? exp * 1000 - 600e3 : Infinity, Date.now() + 4 * 3600e3) };
    streamCache.set(id, entry);
    return entry;
  }).finally(() => pending.delete(id));
  pending.set(id, p);
  return p;
}

app.get('/api/streams/:id', wrap(async (req) => {
  const { info, formats } = await streams(req.params.id);
  const all = [...formats.values()];
  if (info.is_live) {
    const hls = all.filter((f) => f.protocol?.startsWith('m3u8') && f.vcodec !== 'none' && f.acodec !== 'none')
      .sort((a, b) => (b.height || 0) - (a.height || 0))[0];
    return { live: true, hls: hls ? '/hls?u=' + encodeURIComponent(hls.manifest_url || hls.url) : null };
  }
  const https = all.filter((f) => f.protocol === 'https' && f.url);
  // vidéo seule : H.264 jusqu'en 1080p (compatible partout), VP9 au-delà
  const byHeight = new Map();
  for (const f of https.filter((f) => f.vcodec && f.vcodec !== 'none' && f.acodec === 'none')) {
    const h = f.height || 0;
    const score = (f.vcodec.startsWith('avc1') ? 3 : f.vcodec.startsWith('vp09') || f.vcodec === 'vp9' ? 2 : 1)
      + (h > 1080 && !f.vcodec.startsWith('avc1') ? 5 : 0);
    const cur = byHeight.get(h);
    if (!cur || score > cur.score || (score === cur.score && (f.fps || 0) > (cur.f.fps || 0))) byHeight.set(h, { f, score });
  }
  const qualities = [...byHeight.entries()].sort((a, b) => b[0] - a[0])
    .map(([h, { f }]) => ({ label: `${h}p${(f.fps || 0) > 30 ? f.fps : ''}`, height: h, itag: f.format_id, mime: mimeOf(f) }));
  const audio = https.filter((f) => f.vcodec === 'none' && f.acodec && f.acodec !== 'none')
    .sort((a, b) => (b.ext === 'm4a') - (a.ext === 'm4a') || (b.abr || 0) - (a.abr || 0))[0];
  const muxed = https.filter((f) => f.vcodec !== 'none' && f.acodec && f.acodec !== 'none')
    .sort((a, b) => (b.height || 0) - (a.height || 0))[0];
  return {
    live: false,
    qualities,
    audio: audio ? { itag: audio.format_id, mime: mimeOf(audio) } : null,
    muxed: muxed ? { itag: muxed.format_id, label: `${muxed.height}p` } : null,
  };
}));

function mimeOf(f) {
  const video = f.vcodec && f.vcodec !== 'none';
  return `${video ? 'video' : 'audio'}/${f.ext === 'm4a' ? 'mp4' : f.ext}`;
}

app.get('/stream/:id/:itag', async (req, res) => {
  const ac = new AbortController();
  res.on('close', () => ac.abort());
  try {
    for (let attempt = 0; attempt < 2; attempt++) {
      const entry = await streams(req.params.id, attempt > 0);
      const f = entry.formats.get(req.params.itag);
      if (!f?.url) return res.status(404).end();

      const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
      const total = f.filesize || null;
      let start = m && m[1] ? Number(m[1]) : 0;
      let end = m && m[2] ? Number(m[2]) : start + CHUNK - 1;
      end = Math.min(end, start + CHUNK - 1, total ? total - 1 : Infinity);

      const up = await fetch(f.url, {
        headers: { Range: `bytes=${start}-${end}`, 'User-Agent': f.http_headers?.['User-Agent'] || 'Mozilla/5.0' },
        signal: ac.signal,
      });
      if (up.status === 403 && attempt === 0) { await up.body?.cancel(); continue; }
      if (!up.ok) { await up.body?.cancel(); return res.status(up.status).end(); }

      const cr = up.headers.get('content-range');
      const size = total || Number(cr?.split('/')[1]) || null;
      res.status(206);
      res.set({
        'Content-Type': mimeOf(f),
        'Accept-Ranges': 'bytes',
        'Content-Length': up.headers.get('content-length'),
        'Content-Range': cr || `bytes ${start}-${end}/${size ?? '*'}`,
        'Cache-Control': 'private, max-age=3600',
      });
      return Readable.fromWeb(up.body).on('error', () => {}).pipe(res);
    }
  } catch (e) {
    if (!res.headersSent && e.name !== 'AbortError') res.status(502).end();
  }
});

// ---------- proxys miniatures et HLS (domaines Google uniquement) ----------
const IMG_HOSTS = /(^|\.)(ytimg\.com|ggpht\.com|googleusercontent\.com)$/;
const HLS_HOSTS = /(^|\.)(googlevideo\.com|youtube\.com)$/;

function checkedUrl(raw, hosts) {
  try { const u = new URL(raw); return u.protocol === 'https:' && hosts.test(u.hostname) ? u : null; }
  catch { return null; }
}

app.get('/img', async (req, res) => {
  const u = checkedUrl(req.query.u, IMG_HOSTS);
  if (!u) return res.status(400).end();
  try {
    const up = await fetch(u);
    if (!up.ok) return res.status(up.status).end();
    res.set({ 'Content-Type': up.headers.get('content-type') || 'image/jpeg', 'Cache-Control': 'public, max-age=86400' });
    Readable.fromWeb(up.body).on('error', () => {}).pipe(res);
  } catch { res.status(502).end(); }
});

app.get('/hls', async (req, res) => {
  const u = checkedUrl(req.query.u, HLS_HOSTS);
  if (!u) return res.status(400).end();
  try {
    const up = await fetch(u);
    if (!up.ok) return res.status(up.status).end();
    const type = up.headers.get('content-type') || '';
    if (/mpegurl/i.test(type) || u.pathname.endsWith('.m3u8') || u.pathname.includes('/hls_')) {
      const text = await up.text();
      if (text.startsWith('#EXTM3U')) {
        const rewrite = (line) => '/hls?u=' + encodeURIComponent(new URL(line, u).href);
        const out = text.split('\n').map((line) => {
          if (line && !line.startsWith('#')) return rewrite(line.trim());
          return line.replace(/URI="([^"]+)"/g, (_, x) => `URI="${rewrite(x)}"`);
        }).join('\n');
        res.set({ 'Content-Type': 'application/vnd.apple.mpegurl', 'Cache-Control': 'no-cache' });
        return res.send(out);
      }
      res.set('Content-Type', type);
      return res.send(text);
    }
    res.set('Content-Type', type || 'video/mp2t');
    Readable.fromWeb(up.body).on('error', () => {}).pipe(res);
  } catch { res.status(502).end(); }
});

// routes de l'application monopage
app.get(/^\/(watch|results|channel|history|subscriptions)?$/, (_, res) => res.sendFile(path.join(__dirname, 'public/index.html')));

app.listen(PORT, HOST, () => {
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  console.log(`Serveur prêt :\n  http://localhost:${PORT}`);
  for (const ip of ips) console.log(`  http://${ip}:${PORT}   (autres appareils du réseau)`);
});
