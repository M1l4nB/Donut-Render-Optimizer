@echo off
cd /d "%~dp0"
title Tube

rem ===== A REMPLIR =====
set TUBE_DOMAIN=tube.mondomaine.fr
set TUBE_PASSWORD=change-moi
rem ======================

rem HTTPS sur le sous-domaine (fenetre separee)
start "Tube HTTPS" caddy run --config Caddyfile --adapter caddyfile

node server.js
pause
