@echo off
cd /d "%~dp0"
title Tube

rem ===== A REMPLIR =====
set TUBE_DOMAIN=tube.cool
set TUBE_PASSWORD=
rem ======================

rem Caddy repond sur http://tube.cool (port 80) et relaie vers Node (fenetre separee)
start "Tube proxy" caddy run --config Caddyfile.local --adapter caddyfile

node server.js
pause
