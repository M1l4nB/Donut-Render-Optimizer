# Tube — interface YouTube auto-hébergée

Ce PC sert de relais : les appareils du réseau n'ouvrent que `http://<IP-de-ce-PC>:8080`
et c'est le serveur qui va chercher vidéos, miniatures et commentaires sur YouTube.

## Lancer

Double-cliquer sur `start.bat` (ou `npm start`). Les adresses à ouvrir s'affichent dans la console.

Variables optionnelles : `PORT` (8080 par défaut), `HOST`, `PYTHON` (chemin de l'interpréteur ayant yt-dlp).

## Prérequis

- Node.js 20+ puis `npm install`
- Python + yt-dlp : `python -m pip install -U "yt-dlp[default]"`

## Fonctions

Accueil par catégories, recherche (défilement infini), lecture jusqu'en 4K avec choix de qualité,
directs (HLS), description, commentaires, vidéos suggérées, pages de chaînes.
Abonnements et historique sont gardés dans le navigateur de chaque appareil (pas de compte).
Coller un lien YouTube dans la recherche ouvre directement la vidéo.

Raccourcis : `/` recherche, `k`/espace lecture, `j`/`l` ±10 s, flèches ±5 s, `m` muet, `f` plein écran.

## Si quelque chose casse

YouTube change souvent ses API. Mettre à jour d'abord :

```
python -m pip install -U "yt-dlp[default]"
npm update youtubei.js
```

Les vidéos soumises à une limite d'âge ou réservées aux membres ne sont pas lisibles.
